<!doctype html>
<html lang="en">

<head>
  <title>Tarea PHP</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.0-beta1 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
    integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

</head>

<body>
  <header>
    <h1>Datos Estudiantes</h1>
    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Codigo Estudiante</label>
                    <input type="text" name="txt_codigo" id="txt_codigo" class="form-control" placeholder="" aria-describedby="helpId">
                
                </div>
            </div>
        </form>
    </div>

    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Carne</label>
                    <input type="text" name="txt_carne" id="txt_carne" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>

    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Nombres</label>
                    <input type="text" name="txt_nombres" id="txt_nombres" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>

    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Apellidos</label>
                    <input type="text" name="txt_apellidos" id="txt_apellidos" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>

    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Direccion</label>
                    <input type="text" name="txt_direccion" id="txt_direccion" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>

    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Telefono</label>
                    <input type="text" name="txt_telefono" id="txt_telefono" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>
    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Correo electronico</label>
                    <input type="text" name="txt_correo" id="txt_correo_electronico" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>
    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">Tipo sangre</label>
                    <input type="text" name="txt_sangre" id="txt_sangre" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>
    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="" class="form-label">fecha de nacimiento</label>
                    <input type="date" name="txt_nacimiento" id="txt_nacimiento" class="form-control" placeholder="" aria-describedby="helpId">
            
                </div>
            </div>
        </form>
    </div>
    
    <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                
                    <input type="submit" name="btn_agregar" id="btn_agregar" class="btn btn-primary" value="Agregar"
            
                </div>
            </div>

            <div class="col">
                <div class="mb-3">
                
                    <input type="submit" name="btn_eliminar" id="btn_actualizar" class="btn btn-primary" value="Actualizar"
            
                </div>
            </div>
            <div class="col">
                <div class="mb-3">
                
                    <input type="submit" name="btn_eliminar" id="btn_eliminar" class="btn btn-primary" value="Eliminar"
            
                </div>
            </div>
        </form>

<div class="table-responsive">
    <table class="table table-striped
    table-hover	
    table-borderless
    table-primary
    align-middle">
        <thead class="table-light">
            <caption>Table Name</caption>
            <tr>
                <th>Codigo</th>
                <th>Carne</th>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Direccion</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Tipo de Sangre</th>
                <th>Fecha de nacimiento</th>
            </tr>
         
                
            <tfoot>
                
            </tfoot>
    </table>
</div>





  </header>
  <main>
    
  </main>
  <footer>
    <!-- place footer here -->
  </footer>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
    integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js"
    integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous">
  </script>
</body>

</html>