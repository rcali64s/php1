<?php

$db_host = "localhost";
db_usr = "root";
db_pass = "123456";
db_nombre = "estudiantes";

?>